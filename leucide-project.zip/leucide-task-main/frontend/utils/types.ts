

export interface User {
    userName: string;
    type: string
  }